﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class weaponcat : MonoBehaviour
{

    public Transform firePoint;
    public GameObject notePrefab;
    float timer = 0;
    float waitingTime = 2;
    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            Shoot();
        }
    }

    void Shoot()
    {
        Instantiate(notePrefab, firePoint.position, firePoint.rotation);
    }
}
