﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    private Vector2 startPosition;
    private Vector2 newPosition;

    private SpriteRenderer spriteFlip;
    private bool turningTemp = true;
    Animator anim;
    float timer = 0;
    float waitingTime = 2;
    [SerializeField] private int speed = 3;
    [SerializeField] private int maxDistance = 1;
    public int health = 100;
    public GameObject deathEffect;
    public void TakeDamage (int damage)
    {
        health -= damage;
        if(health <=0)
        {
            Instantiate(deathEffect, transform.transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }
    void Start()
    {
        startPosition = transform.position;
        newPosition = transform.position;
        anim = GetComponent<Animator>();
        spriteFlip = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        timer += Time.deltaTime;
        if (timer > waitingTime)
        {
            anim.SetBool("attack", value: true);
            timer = 0;
        }
        else
        {
            anim.SetBool("attack", value: false);
            anim.SetBool("running", value: true);
        }
        anim.SetBool("running", value: true);
        newPosition.x = startPosition.x + (maxDistance * Mathf.Sin(Time.time * speed));
        transform.position = newPosition;
    }
}
