﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet : MonoBehaviour {
    public float speed = 20f;
    public Rigidbody2D rb;
	// Use this for initialization
	void Start () {
        rb.velocity = -transform.right * speed;
	}
    float timer = 0;
    float waitingTime = 3;
    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if (timer > waitingTime)
        {
            Destroy(gameObject);
            timer = 0;
        }
    }
    void OnTriggerEnter2D(Collider2D hitInfo)
    {
        Player player = hitInfo.GetComponent<Player>();
        if(player!=null)
        {
            player.TakeDamage(100);
            Debug.Log(hitInfo.name);
            Destroy(gameObject);
        }

    }
}
